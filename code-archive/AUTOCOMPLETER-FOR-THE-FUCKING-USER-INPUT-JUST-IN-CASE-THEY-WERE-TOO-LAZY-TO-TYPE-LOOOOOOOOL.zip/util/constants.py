ERROR = "[ [bold red]ERROR[/] ]:"
DEBUG = "[ [bold cyan]DEBUG[/] ]:"
WARNING = "[ [bold yellow]WARNING[/] ]:"
INFO = "[ [bold green]INFO[/] ]:"
